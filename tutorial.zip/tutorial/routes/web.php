<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
use App\Notifications\PaymentReceived;

Route::group(['middleware' => ['guest']], function () {

	Route::get('/login','LoginController@index')->name('login');
	Route::post('/login','LoginController@store');

	// Route::get('/register','RegisterController@create');
	// Route::post('/register','RegisterController@store');

	//facebook socialite.
	Route::get('login/facebook', 'Auth\LoginController@redirectToProvider')->name('facebook');
	Route::get('login/facebook/callback', 'Auth\LoginController@handleProviderCallback');
    
    //google socialite.
	Route::get('login/google', 'Auth\LoginController@googleRedirectToProvider')->name('google');
	Route::get('login/google/callback', 'Auth\LoginController@googleHandleProviderCallback');

});

Route::group(['middleware'=>['auth']], function(){

	Route::get('/', function () {

		$user = App\User::find(2);

		$admin = App\User::find(1);

		//$admin->notify(new PaymentReceived($user));

		return view('welcome');
	})->name('home');

	Route::get('/logout','LoginController@destroy');

	Route::get('/users/{id}', 'UserController@show');

	Route::get('/users/edit/{id}', 'UserController@edit');

	Route::get('/articles', 'ArticleController@index');

	Route::get('/articles/{id}', 'ArticleController@show');

	Route::get('/articles/edit/{id}', 'ArticleController@edit');

	Route::patch('/articles/{id}', 'ArticleController@update');

	Route::post('/articles', 'ArticleController@store');

	Route::delete('/articles/{id}', 'ArticleController@destroy');

});
