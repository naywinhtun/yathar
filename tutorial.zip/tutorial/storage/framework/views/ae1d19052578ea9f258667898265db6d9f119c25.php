<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Laravel</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bulma/0.7.1/css/bulma.min.css">
  <style type="text/css">
  @media (min-width: 1280px) {
    .container {
      padding-top:10%;
      width:30%;
    }
  }
  @media (min-width: 1025px) and (max-width: 1280px) {
    .container {
      padding-top:8%;
      width:40%;
    }
  }
  @media (min-width: 768px) and (max-width: 1025px) {
    .container {
      padding-top:5%;
      width:50%;
    }
  }
  @media (min-width: 240px) and (max-width: 768px) {
    .container {
      padding-top:3%;
      width:80%;
    }
  }
  @media (max-width: 240px) {
    .container {
      padding-top:1%;
      width:100%;
    }
  }
</style>
<script defer src="https://use.fontawesome.com/releases/v5.1.0/js/all.js"></script>
</head>
<body>
  <div id="app">   
    <div class="container">
      <div class="message is-dark">
       <div class="message-header">Member Login</div>
       <div class="message-body">
         <!-- <h2 align="center" class="title is-3"></h2> -->
         <form @submit.prevent="onSubmit" @keydown="form.errors.clear()">
           <div class="field">
            <label for="email" class="label">Email:</label>
            <input id="email" name="email" class="input" v-model="form.email">
            <span class="help is-danger" v-if="form.errors.has('email')" v-text="form.errors.get('email')"></span>
          </div>

          <div class="field">
           <label for="password" class="label">Password:</label>
           <input type="password" id="password" name="password" class="input" v-model="form.password">
           <span class="help is-danger" v-if="form.errors.has('password')" v-text="form.errors.get('password')"></span>
         </div>

         <div class="field">
           <button class="button is-primary" :disabled="form.errors.any()">Login</button>
         </div>

         <a href="<?php echo e(route('facebook')); ?>" class="button is-link is-right">
          <span class="icon">
            <i class="fab fa-facebook"></i>
          </span>
          <span>Login with facebook</span>
        </a>

        <a href="<?php echo e(route('google')); ?>" class="button is-link is-right">
          <span class="icon">
            <i class="fab fa-google"></i>
          </span>
          <span>Login with google</span>
        </a>
      </form>
    </div>
  </div>
</div>
<section>
   <my-login></my-login>
</section>
</div>
</div>
<script src="/js/login.js"></script>
</body>
</html>