<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bulma/0.7.1/css/bulma.min.css">
    <link href="https://cdn.jsdelivr.net/npm/animate.css@3.5.1" rel="stylesheet" type="text/css">
    <title>Laravel</title>
    <style type="text/css">
    .flip-list-move {
     transition: transform 5s;
 }
 .list-item {
  display: inline-block;
  margin-right: 10px;
}
.list-enter-active, .list-leave-active {
  transition: all 5s;
}
.list-enter, .list-leave-to /* .list-leave-active below version 2.1.8 */ {
  opacity: 0;
  transition: transform 5s;
  transform: translateY(30px);
}
</style>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.js"></script>
<script defer src="https://use.fontawesome.com/releases/v5.1.0/js/all.js"></script>
<script type="text/javascript">
  $(document).ready(function() {
      // Check for click events on the navbar burger icon
      $(".navbar-burger").click(function() {

         // Toggle the "is-active" class on both the "navbar-burger" and the "navbar-menu"
         $(".navbar-burger").toggleClass("is-active");
         $(".navbar-menu").toggleClass("is-active");

     });
  });
</script>
</head>
<body>
    <div id="app">

        <?php echo $__env->make('layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <section class="section">
           <div class="container">
            <router-view></router-view>
        </div>
    </section>
    <section>
        <div class="message" :style="{ fontSize: articleFontSize +'em' }">
            <!-- <my-example></my-example> -->
            <my-message v-for="article in articles" v-on:enlarge-text="onEnlargeText" v-bind:key="article.id" v-bind:title="article.title" v-bind:body="article.body"></my-message>
        </div>
    </section>

    <section>
        <div class="container">
            <div>
                <bootstrap-date-input
                data-date-picker="activated"
                class="date-picker-theme-dark"
                ></bootstrap-date-input>
            </div>

            <div id="list-demo">
              <button v-on:click="add">Add</button>
              <button v-on:click="remove">Remove</button>
              <transition-group name="list" tag="p">
                <span v-for="item in items" v-bind:key="item" v-text="item" class="list-item">
                </span>
            </transition-group>
        </div>

        <div id="flip-list-demo" class="demo">
          <button v-on:click="shuffle">Shuffle</button>
          <button v-on:click="add">Add</button>
          <button v-on:click="remove">Remove</button>

          <transition-group name="flip-list" tag="ul">
            <li v-for="item in items" v-bind:key="item" v-text="item">

            </li>
        </transition-group>

        <button @click="show = !show">
            Toggle render
        </button><br>

        <transition
        name="custom-classes-transition"
        enter-active-class="animated tada"
        leave-active-class="animated bounceOutRight"
        >
        <p v-if="show">hello</p>
    </transition>

</div>
</div>
</section>
<div class="tabs is-centered">
  <ul>
    <li class="is-active"><a>Pictures</a></li>
    <li><a>Music</a></li>
    <li><a>Videos</a></li>
    <li><a>Documents</a></li>
</ul>
</div>
        <!-- <section class="section">
            <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.1.0/fullcalendar.min.css' />

            <h3></h3>

            <div id='calendar'></div>

            <script src="//code.jquery.com/jquery-1.11.3.min.js"></script>
            <script src='https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.17.1/moment.min.js'></script>
            <script src='https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.1.0/fullcalendar.min.js'></script>
            <script>
                $(document).ready(function() {
        // page is now ready, initialize the calendar...
        $('#calendar').fullCalendar({
            // put your options and callbacks here
            events : [
            {
                title : 'NayWinHtun1',
                start : '2018-07-10 07:14:23',
                url : '#',
            },
            ]
        })
    });
</script>
</section> -->

</div>
<script src="/js/app.js"></script>
<script defer src="https://use.fontawesome.com/releases/v5.1.0/js/all.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/lodash.js/4.14.1/lodash.min.js"></script>
</body>
</html>
