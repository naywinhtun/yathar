
/**
 * First we will load all of this project's JavaScript dependencies which
 * includes Vue and other libraries. It is a great starting point when
 * building robust, powerful web applications using Vue and Laravel.
 */


 import './bootstrap';
 import router from './routes';

/**
 * Next, we will create a fresh Vue application instance and attach it to
 * the page. Then, you may begin adding components to this application
 * or customize the JavaScript scaffolding to fit your unique needs.
 */

 Vue.component('my-message', { 
  data: function () {
    return {
      count: 0,
      articleFontSize: 0
    }
  },
  props: ['title','body'],

  template: `<div class="container">
  <h1>{{ title }}</h1>
  <h2>{{ body }}</h2>
  <br>
  <button v-on:click="$emit('enlarge-text', 0.1)">
  Enlarge text
  </button>
  <br>
  <button v-on:click="count++">You clicked me {{ count }} times.</button>
  </div>`
});

Vue.component('bootstrap-date-input', { 
  template: `<input type="date" class="form-control">`
});

 import MyExample from './components/MyExample.vue';
//import MyExample1 from './components/MyExample1.vue';
const app = new Vue({
  el: '#app',

  components: {
   'my-example': MyExample
 },
 data: {
  articles: [],
  articleFontSize: 1,
  items: [1,2,3,4,5,6,7,8,9],
  nextNum: 10,
  show: true
},
created: function () {
    // Alias the component instance as `vm`, so that we  
    // can access it inside the promise function
    var vm = this
    // Fetch our array of posts from an API
    fetch('http://localhost:8001/articles')
    .then(function (response) {
      return response.json()
    })
    .then(function (data) {
      vm.articles = data
    })
  },
  methods: {
    onEnlargeText: function (enlargeAmount) {
      this.articleFontSize += enlargeAmount
    },

    shuffle: function () {
      this.items = _.shuffle(this.items)
    },
    randomIndex: function () {
      return Math.floor(Math.random() * this.items.length)
    },
    add: function () {
      this.items.splice(this.randomIndex(), 0, this.nextNum++)
    },
    remove: function () {
      this.items.splice(this.randomIndex(), 1)
    }
  },
  router
});
