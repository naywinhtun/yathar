<section class="section">
  <nav class="navbar is-fixed-top is-primary">
    <div class="navbar-brand">
      <a class="navbar-item">
        <!-- <img src="http://picoinnovation.com/img/logo.png" alt="Bulma: a modern CSS framework based on Flexbox" > -->
        NayWinHtun
      </a>
      <div class="navbar-burger burger" data-target="navbarExampleTransparentExample">
        <span></span>
        <span></span>
        <span></span>
      </div>
    </div>

    <div id="navbarExampleTransparentExample" class="navbar-menu">
      <div class="navbar-start">
      <!-- <a class="navbar-item" href="https://bulma.io/">
        Home
      </a> -->
      <!-- <div class="navbar-item has-dropdown is-hoverable">
        <a class="navbar-link" href="/documentation/overview/start/">
          Docs
        </a>
        <div class="navbar-dropdown is-boxed">
          <a class="navbar-item" href="/documentation/overview/start/">
            Overview
          </a>
          <a class="navbar-item" href="https://bulma.io/documentation/modifiers/syntax/">
            Modifiers
          </a>
          <a class="navbar-item" href="https://bulma.io/documentation/columns/basics/">
            Columns
          </a>
          <a class="navbar-item" href="https://bulma.io/documentation/layout/container/">
            Layout
          </a>
          <a class="navbar-item" href="https://bulma.io/documentation/form/general/">
            Form
          </a>
          <hr class="navbar-divider">
          <a class="navbar-item" href="https://bulma.io/documentation/elements/box/">
            Elements
          </a>
          <a class="navbar-item is-active" href="https://bulma.io/documentation/components/breadcrumb/">
            Components
          </a>
        </div>
      </div> -->
    </div>
    
    <div class="navbar-end">

      <router-link class="navbar-item" to="/" exact>
        <a style="color: #17243a">Home</a>
      </router-link>

      <router-link class="navbar-item" to="/example">
        <a style="color: #17243a">Examples</a>
      </router-link>
      
      <router-link class="navbar-item" to="/about">
        <a style="color: #17243a">About</a>
      </router-link>

      <router-link class="navbar-item" to="/contact">
        <a style="color: #17243a">Contact</a>
      </router-link>

      <div class="navbar-item has-dropdown is-hoverable">
        <a class="navbar-link" href="#" style="color: #17243a">
         <span class="icon">
          <i class="fas fa-user"></i>
        </span>
        {{ Auth::user()->name }}
      </a>
      <div class="navbar-dropdown is-right">
        <!-- <a class="navbar-item" href="/documentation/overview/start/">
          Overview
        </a>
        <a class="navbar-item" href="https://bulma.io/documentation/modifiers/syntax/">
          Modifiers
        </a>
        <a class="navbar-item" href="https://bulma.io/documentation/columns/basics/">
          Columns
        </a>
        <a class="navbar-item" href="https://bulma.io/documentation/layout/container/">
          Form
        </a> -->
        <a class="navbar-item" href="/logout">
          Logout
        </a>
          <!-- <hr class="navbar-divider">
          <a class="navbar-item" href="https://bulma.io/documentation/elements/box/">
            Elements
          </a>
          <a class="navbar-item is-active" href="https://bulma.io/documentation/components/breadcrumb/">
            Components
          </a> -->
        </div>
      </div>
      
      <!-- <span class="navbar-item">
        <a class="button is-info is-inverted">
          <span class="icon">
            <i class="fas fa-download"></i>
          </span>
          <span>Download</span>
        </a>
      </span> -->
    </div>
  </div>
</nav>
</section>