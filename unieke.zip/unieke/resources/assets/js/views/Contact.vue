<template>
   <h1>Hay , I am Contact view.Okay?{{ message }}</h1>
</template>

<script>
export default {
	data(){
	   return { message : "Contact" };
	}
};
</script>