<template>
    <div class="container">
       <h1>Hay , I am Example view.Okay?{{ message }}</h1>
       <add-article @completed='addArticle'></add-article>
   </div>
</template>

<script>
import AddArticle from '../components/AddArticle.vue';
export default {
    components:{ AddArticle },
	data(){
	   return { message : "Example" };
	},
	methods:{
           addArticle(article){
              location.href = '/';
           }
        }
};
</script>