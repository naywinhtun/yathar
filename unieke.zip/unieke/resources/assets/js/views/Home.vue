<template>
    <div class="container">
      <table class="table" style="width:100%;">
         <thead>
            <tr>
               <th>Title</th>
               <th>Body</th>
               <th>Posted By</th>
               <th colspan="3">Manage</th>
            </tr>
         </thead>
         <tbody>
            <tr v-for="article in articles">
               <th>{{ article.title }}</th>
               <th>{{ article.body }}</th>
               <th>{{ article.user.name }}</th>
               <th>
               <router-link :to="{ name: 'articles', params: { id: article.id } }">
                 <a class="button is-link">View</a>
               </router-link>
               </th>
               <th>
               <router-link :to="{ name: 'editArticle', params: { id: article.id } }">
                 <a class="button is-info">Edit</a>
               </router-link>
               </th>
               <th><button class="button is-danger" @click="deleteArticle(article)">Danger</button></th>
            </tr>
         </tbody>
      </table>
      </hr>
      <add-article @completed='addArticle'></add-article>
    </div>
</template>

<script>
import AddArticle from '../components/AddArticle.vue';
export default {
    components:{ AddArticle },
	data(){
	   return { 
	     articles:[]
	   };
	},

	created(){
	  axios.get('/articles')
	       .then(response=>this.articles=response.data);
	},

	methods:{
           addArticle(article){
              this.articles.unshift(article);

              //alert('Your article has been added to the article');

              window.scrollTo(0,0);
           },
           deleteArticle(article){
              axios.delete('/articles/'+article.id)
	               .then(response=>{ location.href = '/' });
           }
        }
};
</script>