<template>
   <div class="message">
     <div class="message-header">Update Article...</div>
     <div class="message-body">
       <form @submit.prevent="onSubmit" @keydown="form.errors.clear()">
         <div class="field">
            <label class="label">Title</label>
            <div class="control">
                <input class="input" type="text" v-model="form.title" value="article.title">
                <span class="help is-danger" v-if="form.errors.has('title')" v-text="form.errors.get('title')"></span>
            </div>
         </div>

         <div class="field">
              <label class="label">Body</label>
              <div class="control">
                  <textarea class="textarea" v-model="form.body">{{article.body}}</textarea>
                  <span class="help is-danger" v-if="form.errors.has('body')" v-text="form.errors.get('body')"></span>
              </div>
         </div>

         <div class="field">
              <button class="button is-primary" type="submit" :disabled="form.errors.any()">Submit</button>
         </div>

       </form>
     </div>
  </div>
</template>

<script>
export default {
	data(){
	   return { 
	     article : [],
	     form : new Form({
	       title : '',
	       body : ''
	     })
	   };
	},

	created(){
	  axios.get('/articles/edit/'+this.$route.params.id)
	       .then(response => {
	         this.form.title=response.data.title;
	         this.form.body=response.data.body;
	       });
	},

	methods:{
	 onSubmit(){
	   this.form
             .patch('/articles/'+this.$route.params.id)
             .then(response => { location.href = '/' });
	 }
	}

};
</script>