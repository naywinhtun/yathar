<template>
   <div class="container">
     <h1>Hay , I am Edit User view.Okay?{{ message }}</h1>
     <div v-if="user">
       <p>{{ user.name }}</p>
       <p>{{ user.email }}</p>
     </div>
     <div v-else="user">
      <h2>There is no user information.</h2>
     </div>
   </div>
</template>

<script>
export default {
	data(){
	   return { 
	   user : [],
	   message : "About"
	   };
	},

	created(){
	  axios.get('/users/edit/'+this.$route.params.id)
	       .then(response => this.user=response.data);
	}
};
</script>