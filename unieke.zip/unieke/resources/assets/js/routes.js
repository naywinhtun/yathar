import VueRouter from 'vue-router';

let routes = [

  // {
  // 	path:'/',
  // 	component:require('./views/Home')
  // },
  {
  	path:'/example',
  	component:require('./views/Example')
  },
  {
    name:'about',
    path:'/about',
    component:require('./views/About')
  },
  // {
  // 	name:'articles',
  // 	path:'/articles/:id',
  // 	component:require('./views/ViewArticle')
  // },
  {
  	path:'/contact',
  	component:require('./views/Contact')
  },
  // {
  // 	name:'editArticle',
  // 	path:'/edit/articles/:id',
  // 	component:require('./views/EditArticle')
  // },

];

export default new VueRouter({
   routes,
   
   linkActiveClass:'is-active'
});