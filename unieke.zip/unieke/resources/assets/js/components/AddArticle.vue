<template>
  <div class="message">
     <div class="message-header">Add New Article...</div>
     <div class="message-body">
     <form @submit.prevent="onSubmit" @keydown="form.errors.clear()">
       <div class="field">
           <label class="label">Title</label>
           <div class="control">
                <input class="input" type="text" v-model="form.title" placeholder="title">
                <span class="help is-danger" v-if="form.errors.has('title')" v-text="form.errors.get('title')"></span>
           </div>
       </div>

       <div class="field">
           <label class="label">Body</label>
           <div class="control">
                <input class="input" type="text" v-model="form.body" placeholder="description of the title">
                <span class="help is-danger" v-if="form.errors.has('body')" v-text="form.errors.get('body')"></span>
           </div>
       </div>
       <div class="field">
           <div class="control">
                <button class="button is-primary" :disabled="form.errors.any()">Submit</button>
            </div>
       </div>
     </form>
    </div>
  </div>
</template>

<script>
export default{
 
  data(){

    return {
      form : new Form({
      'title':'',
      'body':''
      })

    };

  },
  methods:{
    onSubmit(){
       this.form
             .post('/articles')
             .then(article=>this.$emit('completed',article));
    }
  }
	
};
</script>