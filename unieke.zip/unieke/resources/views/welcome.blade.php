@extends('layouts.master')

@section('content')
@include('layouts.navbar')
<header class="masthead text-center text-white d-flex">
  <div class="container my-auto">
    <div class="row">
      <div class="col-lg-10 mx-auto">
        <h1 class="text-uppercase">
          <strong>For your bussiness achievement</strong>
      </h1>
      <hr>
  </div>
  <div class="col-lg-8 mx-auto">
    <p class="text-faded mb-5">Unieke Creation can support your business to achieve in global and start going forward together with successful!</p>
    <a class="btn btn-primary btn-xl js-scroll-trigger" href="#about">Find Out More</a>
</div>
</div>
</div>
</header>

<section class="bg-primary" id="about">
  <div class="container">
    <div class="row">
      <div class="col-lg-8 mx-auto text-center">
        <h2 class="section-heading text-white">We've got what you need!</h2>
        <hr class="light my-4">
        <p class="text-faded mb-4">Unieke Creation has everything you need to get your new website up and running in no time! All of services on Unieke Creation are good and standard.</p>
        <a class="btn btn-light btn-xl js-scroll-trigger" href="#services">Get Started!</a>
    </div>
</div>
</div>
</section>

<section id="services">
  <div class="container">
    <div class="row">
      <div class="col-lg-12 text-center">
        <h2 class="section-heading">Our Services</h2>
        <hr class="my-4">
    </div>
</div>
</div>
<div class="container">
    <div class="row">
      <div class="col-lg-3 col-md-6 text-center">
        <div class="service-box mt-5 mx-auto">
          <i class="fa fa-4x fa-wrench text-primary mb-3 sr-icons"></i>
          <h3 class="mb-3">Management</h3>
          <p class="text-muted mb-0">For planning, scheduling, resource allocation and change management.</p>
      </div>
  </div>
  <div class="col-lg-3 col-md-6 text-center">
    <div class="service-box mt-5 mx-auto">
      <i class="fa fa-4x fa-paper-plane text-primary mb-3 sr-icons"></i>
      <h3 class="mb-3">Ready to Ship</h3>
      <p class="text-muted mb-0">Publishing software around the world.</p>
  </div>
</div>
<div class="col-lg-3 col-md-6 text-center">
    <div class="service-box mt-5 mx-auto">
      <i class="fa fa-4x fa-newspaper-o text-primary mb-3 sr-icons"></i>
      <h3 class="mb-3">Up to Date</h3>
      <p class="text-muted mb-0">We update dependencies to keep many fresh.</p>
  </div>
</div>
<div class="col-lg-3 col-md-6 text-center">
    <div class="service-box mt-5 mx-auto">
      <i class="fa fa-4x fa-heart text-primary mb-3 sr-icons"></i>
      <h3 class="mb-3">Made with Love</h3>
      <p class="text-muted mb-0">You have to make your websites with love these days!</p>
  </div>
</div>
</div>
</div>
</section>

<section class="p-5" id="portfolio">
  <div class="container-fluid p-0">
    <div class="row no-gutters popup-gallery">
      <div class="col-lg-4 col-sm-6" style="bottom: 5px;">
        <a class="portfolio-box" href="img/portfolio/p1.jpg">
          <img class="img-fluid" src="img/portfolio/p1.jpg" alt="">
          <div class="portfolio-box-caption">
            <div class="portfolio-box-caption-content">
              <div class="project-category text-faded">
                Category
            </div>
            <div class="project-name">
                Photo
            </div>
        </div>
    </div>
</a>
</div>
<div class="col-lg-4 col-sm-6" style="bottom: 5px;">
    <a class="portfolio-box" href="img/portfolio/p2.jpg">
      <img class="img-fluid" src="img/portfolio/p2.jpg" alt="">
      <div class="portfolio-box-caption">
        <div class="portfolio-box-caption-content">
          <div class="project-category text-faded">
            Category
        </div>
        <div class="project-name">
            Photo
        </div>
    </div>
</div>
</a>
</div>
<div class="col-lg-4 col-sm-6" style="bottom: 5px;">
    <a class="portfolio-box" href="img/portfolio/p3.jpg">
      <img class="img-fluid" src="img/portfolio/p3.jpg" alt="">
      <div class="portfolio-box-caption">
        <div class="portfolio-box-caption-content">
          <div class="project-category text-faded">
            Category
        </div>
        <div class="project-name">
            Photo
        </div>
    </div>
</div>
</a>
</div>
<div class="col-lg-4 col-sm-6">
    <a class="portfolio-box" href="img/portfolio/p4.jpg">
      <img class="img-fluid" src="img/portfolio/p4.jpg" alt="">
      <div class="portfolio-box-caption">
        <div class="portfolio-box-caption-content">
          <div class="project-category text-faded">
            Category
        </div>
        <div class="project-name">
            Photo
        </div>
    </div>
</div>
</a>
</div>
<div class="col-lg-4 col-sm-6">
    <a class="portfolio-box" href="img/portfolio/p8.jpg">
      <img class="img-fluid" src="img/portfolio/p8.jpg" alt="">
      <div class="portfolio-box-caption">
        <div class="portfolio-box-caption-content">
          <div class="project-category text-faded">
            Category
        </div>
        <div class="project-name">
            Photo
        </div>
    </div>
</div>
</a>
</div>
<div class="col-lg-4 col-sm-6">
    <a class="portfolio-box" href="img/portfolio/p6.jpg">
      <img class="img-fluid" src="img/portfolio/p6.jpg" alt="">
      <div class="portfolio-box-caption">
        <div class="portfolio-box-caption-content">
          <div class="project-category text-faded">
            Category
        </div>
        <div class="project-name">
            Photo
        </div>
    </div>
</div>
</a>
</div>
</div>
</div>
</section>

<!-- <section class="bg-dark text-white">
  <div class="container text-center">
    <h2 class="mb-4">Free Download at Start Bootstrap!</h2>
    <a class="btn btn-light btn-xl sr-button" href="http://startbootstrap.com/template-overviews/creative/">Download Now!</a>
</div>
</section> -->

<!-- Section -->
  <section class="bg-dark text-white">
    <div class="container">
      <div class="row">
        <div class="col-lg-12 col-md-12">
          <div class="title-container text-left sm">
            <div class="title-wrap">
              <h4 class="title">Default Map</h4>
              <span class="separator line-separator"></span>
            </div>              
          </div><!-- Name -->          
          <div style="height: 376px;" class="map-canvas" data-zoom="15" data-lat="16.777095" data-lng="96.175238" data-title="Unieke Creation" data-type="roadmap" data-hue="" data-content="Company Name&lt;br&gt; Contact: +95 (09) 794001541&lt;br&gt; naywinhtun2018@gmail.com"></div>
        </div><!-- Column -->
      </div><!-- Row -->
    </div><!-- Container -->
  </section><!-- Section -->
  <my-message></my-message>
  <my-message v-bind:key="123" v-bind:title="MgNay" v-bind:body="Thanks"></my-message>
<section id="contact">
  <div class="container">
    <div class="row">
      <div class="col-lg-8 mx-auto text-center">
        <h2 class="section-heading">Let's Get In Touch!</h2>
        <hr class="my-4">
        <p class="mb-5">Ready to start your next project with us? That's great! Give us a call or send us an email and we will get back to you as soon as possible!</p>
    </div>
</div>
<div class="row">
  <div class="col-lg-4 ml-auto text-center">
    <i class="fa fa-phone fa-3x mb-3 sr-contact"></i>
    <p>+95 9794001541</p>
</div>
<div class="col-lg-4 mr-auto text-center">
    <i class="fa fa-envelope-o fa-3x mb-3 sr-contact"></i>
    <p>
      <a href="mailto:your-email@your-domain.com">naywinhtun2018@gmail.com</a>
  </p>
</div>
</div>
</div>
</section>

<script type="text/javascript">
  window.onload = MapLoadScript;
function GmapInit() {
    Gmap = jQuery('.map-canvas');
    Gmap.each(function() {
    var $this           = $(this),
      lat             = 16.777095,
      lng             = 96.175238,
      zoom            = 15,
      scrollwheel     = true,
      zoomcontrol   = true,
      draggable       = true,
      mapType         = google.maps.MapTypeId.ROADMAP,
      title           = '',
      contentString   = '',
      dataLat         = $this.data('lat'),
      dataLng         = $this.data('lng'),
      dataZoom        = $this.data('zoom'),
      dataType        = $this.data('type'),
      dataScrollwheel = $this.data('scrollwheel'),
      dataZoomcontrol = $this.data('zoomcontrol'),
      dataHue         = $this.data('hue'),
      dataSaturation  = $this.data('saturation'),
      dataLightness   = $this.data('lightness'),
      dataTitle       = $this.data('title'),
      dataContent     = $this.data('content');
      
    if( dataZoom !== undefined && dataZoom !== false ) {
      zoom = parseFloat(dataZoom);
    }
    if( dataLat !== undefined && dataLat !== false ) {
      lat = parseFloat(dataLat);
    }
    if( dataLng !== undefined && dataLng !== false ) {
      lng = parseFloat(dataLng);
    }
    if( dataScrollwheel !== undefined && dataScrollwheel !== null ) {
      scrollwheel = dataScrollwheel;
    }
    if( dataZoomcontrol !== undefined && dataZoomcontrol !== null ) {
      zoomcontrol = dataZoomcontrol;
    }
    if( dataType !== undefined && dataType !== false ) {
      if( dataType == 'satellite' ) {
        mapType = google.maps.MapTypeId.SATELLITE;
      } else if( dataType == 'hybrid' ) {
        mapType = google.maps.MapTypeId.HYBRID;
      } else if( dataType == 'terrain' ) {
        mapType = google.maps.MapTypeId.TERRAIN;
      }       
    }
    if( dataTitle !== undefined && dataTitle !== false ) {
      title = dataTitle;
    }
    if( navigator.userAgent.match(/iPad|iPhone|Android/i) ) {
      draggable = false;
    }
    
    var mapOptions = {
      zoom        : zoom,
      scrollwheel : scrollwheel,
      zoomControl : zoomcontrol,
      draggable   : draggable,
      center      : new google.maps.LatLng(lat, lng),
      mapTypeId   : mapType
    };    
    var map = new google.maps.Map($this[0], mapOptions);
    
    var image = '/img/default/map-marker.png';
    if( dataContent !== undefined && dataContent !== false ) {
      contentString = '<div class="map-data">' + '<h6>' + title + '</h6>' + '<div class="map-content">' + dataContent + '</div>' + '</div>';
    }
    var infowindow = new google.maps.InfoWindow({
      content: contentString
    });
    
    var marker = new google.maps.Marker({
      position : new google.maps.LatLng(lat, lng),
      map      : map,
      icon     : image,
      title    : title
    });
    if( dataContent !== undefined && dataContent !== false ) {
      google.maps.event.addListener(marker, 'click', function() {
        infowindow.open(map,marker);
      });
    }
    
    if( dataHue !== undefined && dataHue !== false ) {
      var styles = [
      {
        stylers : [
        { hue : dataHue },
        { saturation: dataSaturation },
        { lightness: dataLightness }
        ]
      }
      ];
      map.setOptions({styles: styles});
    }
   });   
}

function MapLoadScript() {
  
  var script = document.createElement('script');
  script.type = 'text/javascript';
  script.src = 'https://maps.googleapis.com/maps/api/js?v=3.exp&sensor=false&' + 'callback=GmapInit';
  document.body.appendChild(script);
}
</script>

@endsection